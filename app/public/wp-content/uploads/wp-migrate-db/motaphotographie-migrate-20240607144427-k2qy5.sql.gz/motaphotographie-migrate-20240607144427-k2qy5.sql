# Migration de base de données MySQL WordPress
#
# Généré : Friday 7. June 2024 14:44 UTC
# Nom d’hôte : localhost
# Base de données : `local`
# URL: //motaphotographie.local
# Path: C:\\Users\\Nicolas\\Local Sites\\motaphotographie\\app\\public
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, acf-post-type, acf-taxonomy, attachment, customize_changeset, nav_menu_item, page, photographies, post, wp_navigation, wpcf7_contact_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Supprimer toute table existante `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Structure de la table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_commentmeta`
#

#
# Fin du contenu des données de la table `wp_commentmeta`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Structure de la table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-05-21 10:20:22', '2024-05-21 10:20:22', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0) ;

#
# Fin du contenu des données de la table `wp_comments`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Structure de la table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_links`
#

#
# Fin du contenu des données de la table `wp_links`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Structure de la table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=458 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://motaphotographie.local', 'yes'),
(2, 'home', 'http://motaphotographie.local', 'yes'),
(3, 'blogname', 'MotaPhotographie', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'dev-email@wpengine.local', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd/m/Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:120:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:57:"categorie_photos/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?categorie_photos=$matches[1]&feed=$matches[2]";s:52:"categorie_photos/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?categorie_photos=$matches[1]&feed=$matches[2]";s:33:"categorie_photos/([^/]+)/embed/?$";s:49:"index.php?categorie_photos=$matches[1]&embed=true";s:45:"categorie_photos/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?categorie_photos=$matches[1]&paged=$matches[2]";s:27:"categorie_photos/([^/]+)/?$";s:38:"index.php?categorie_photos=$matches[1]";s:48:"formats/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?formats=$matches[1]&feed=$matches[2]";s:43:"formats/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?formats=$matches[1]&feed=$matches[2]";s:24:"formats/([^/]+)/embed/?$";s:40:"index.php?formats=$matches[1]&embed=true";s:36:"formats/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?formats=$matches[1]&paged=$matches[2]";s:18:"formats/([^/]+)/?$";s:29:"index.php?formats=$matches[1]";s:41:"photographies/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"photographies/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"photographies/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"photographies/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"photographies/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"photographies/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"photographies/([^/]+)/embed/?$";s:46:"index.php?photographies=$matches[1]&embed=true";s:34:"photographies/([^/]+)/trackback/?$";s:40:"index.php?photographies=$matches[1]&tb=1";s:42:"photographies/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?photographies=$matches[1]&paged=$matches[2]";s:49:"photographies/([^/]+)/comment-page-([0-9]{1,})/?$";s:53:"index.php?photographies=$matches[1]&cpage=$matches[2]";s:38:"photographies/([^/]+)(?:/([0-9]+))?/?$";s:52:"index.php?photographies=$matches[1]&page=$matches[2]";s:30:"photographies/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"photographies/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"photographies/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"photographies/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"photographies/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:36:"photographies/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:101:"C:\\Users\\Nicolas\\Local Sites\\motaphotographie\\app\\public/wp-content/themes/motaphotographie/style.css";i:1;s:0:"";}', 'no'),
(40, 'template', 'motaphotographie', 'yes'),
(41, 'stylesheet', 'motaphotographie', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '57155', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '37', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '35', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1731838822', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'wp_attachment_pages_enabled', '0', 'yes'),
(100, 'initial_db_version', '57155', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(102, 'fresh_site', '0', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:10:{i:1717773624;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1717798824;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1717798870;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1717842024;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1717842070;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1717842071;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1718107471;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1718187624;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1718281508;a:1:{s:27:"acf_update_site_health_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(123, 'recovery_keys', 'a:0:{}', 'yes'),
(147, 'can_compress_scripts', '1', 'yes'),
(148, 'theme_mods_twentytwentyfour', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1716290856;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'no'),
(151, 'finished_updating_comment_type', '1', 'yes'),
(155, 'current_theme', 'MotaPhotographie', 'yes'),
(156, 'theme_mods_motaphotographie', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:14:"menu_principal";i:10;s:15:"menu_secondaire";i:11;}s:18:"custom_css_post_id";i:-1;s:11:"custom_logo";i:34;}', 'yes'),
(157, 'theme_switched', '', 'yes'),
(164, 'WPLANG', 'fr_FR', 'yes'),
(165, 'new_admin_email', 'dev-email@wpengine.local', 'yes'),
(169, 'recently_activated', 'a:0:{}', 'yes'),
(173, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.9.5";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1716293168;s:7:"version";s:5:"5.9.5";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(176, 'acf_first_activated_version', '6.2.9', 'yes'),
(177, 'acf_version', '6.3.1', 'yes'),
(181, 'cptui_new_install', 'false', 'yes'),
(182, 'cptui_post_types', 'a:1:{s:13:"photographies";a:34:{s:4:"name";s:13:"photographies";s:5:"label";s:13:"Photographies";s:14:"singular_label";s:12:"Photographie";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:10:"can_export";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";N;s:20:"register_meta_box_cb";N;s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:30:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";s:14:"name_admin_bar";s:0:"";s:14:"item_published";s:0:"";s:24:"item_published_privately";s:0:"";s:22:"item_reverted_to_draft";s:0:"";s:12:"item_trashed";s:0:"";s:14:"item_scheduled";s:0:"";s:12:"item_updated";s:0:"";}s:15:"custom_supports";s:0:"";s:16:"enter_title_here";s:0:"";}}', 'yes'),
(185, 'cptui_taxonomies', 'a:2:{s:7:"formats";a:28:{s:4:"name";s:7:"formats";s:5:"label";s:7:"formats";s:14:"singular_label";s:6:"format";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:13:"show_tagcloud";s:5:"false";s:4:"sort";s:5:"false";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:6:"labels";a:23:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:13:"back_to_items";s:0:"";s:22:"name_field_description";s:0:"";s:24:"parent_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:22:"desc_field_description";s:0:"";}s:11:"meta_box_cb";s:0:"";s:12:"default_term";s:0:"";s:12:"object_types";a:1:{i:0;s:13:"photographies";}}s:17:"categorie_photos ";a:28:{s:4:"name";s:16:"categorie_photos";s:5:"label";s:19:"catégories_photos ";s:14:"singular_label";s:16:"catégorie_photo";s:11:"description";s:49:"Type d&#39;évènement a l&#39;origine du cliché";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:13:"show_tagcloud";s:5:"false";s:4:"sort";s:5:"false";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:6:"labels";a:23:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:13:"back_to_items";s:0:"";s:22:"name_field_description";s:0:"";s:24:"parent_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:22:"desc_field_description";s:0:"";}s:11:"meta_box_cb";s:0:"";s:12:"default_term";s:0:"";s:12:"object_types";a:1:{i:0;s:13:"photographies";}}}', 'yes'),
(216, 'site_logo', '34', 'yes'),
(219, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(238, 'category_children', 'a:0:{}', 'yes'),
(281, 'acf_site_health', '{"version":"6.3.1","plugin_type":"Free","wp_version":"6.5.3","mysql_version":"8.0.16","is_multisite":false,"active_theme":{"name":"MotaPhotographie","version":"1.1","theme_uri":"https:\\/\\/github.com\\/nicolasmuh\\/motaphotographie","stylesheet":false},"active_plugins":{"advanced-custom-fields\\/acf.php":{"name":"Advanced Custom Fields","version":"6.3.1","plugin_uri":"https:\\/\\/www.advancedcustomfields.com"},"contact-form-7\\/wp-contact-form-7.php":{"name":"Contact Form 7","version":"5.9.5","plugin_uri":"https:\\/\\/contactform7.com\\/"},"custom-post-type-ui\\/custom-post-type-ui.php":{"name":"Custom Post Type UI","version":"1.16.0","plugin_uri":"https:\\/\\/github.com\\/WebDevStudios\\/custom-post-type-ui\\/"},"wp-migrate-db\\/wp-migrate-db.php":{"name":"WP Migrate Lite","version":"2.6.11","plugin_uri":"https:\\/\\/wordpress.org\\/plugins\\/wp-migrate-db\\/"}},"ui_field_groups":"1","php_field_groups":"0","json_field_groups":"0","rest_field_groups":"0","number_of_fields_by_type":{"radio":1,"text":1,"number":1},"number_of_third_party_fields_by_type":[],"post_types_enabled":true,"ui_post_types":"5","json_post_types":"0","ui_taxonomies":"5","json_taxonomies":"0","rest_api_format":"light","admin_ui_enabled":true,"field_type-modal_enabled":true,"field_settings_tabs_enabled":false,"shortcode_enabled":true,"registered_acf_forms":"0","json_save_paths":1,"json_load_paths":1,"last_updated":1717759891}', 'no'),
(361, 'auto_update_plugins', 'a:4:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'no'),
(453, 'core_updater.lock', '1717771322', 'no'),
(457, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1717771467;}', 'no') ;

#
# Fin du contenu des données de la table `wp_options`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Structure de la table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=314 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 6, '_form', '<div class="F-Nom">\n  <label> Nom\n    [text* your-name autocomplete:name] </label>\n</div>\n<div class="F-Email">\n <label> E-mail\n    [email* your-email autocomplete:email] </label>\n</div>\n<div class="F-reference">\n <label> Réf. PPHOTO\n    [text* your-photo] </label>\n</div>\n<div class="F-message">\n <label> MESSAGE (optional)\n    [textarea your-message] </label>\n</div>\n<div class="F-button">\n [submit "Envoyer"]\n</div>'),
(4, 6, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:48:"[_site_title] <wordpress@motaphotographie.local>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:191:"From: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis is a notification that a contact form was submitted on your website ([_site_title] [_site_url]).";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(5, 6, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:48:"[_site_title] <wordpress@motaphotographie.local>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:220:"Message Body:\n[your-message]\n\n-- \nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(6, 6, '_messages', 'a:22:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:27:"Please fill out this field.";s:16:"invalid_too_long";s:32:"This field has a too long input.";s:17:"invalid_too_short";s:33:"This field has a too short input.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:31:"The uploaded file is too large.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:12:"invalid_date";s:46:"Veuillez saisir une date au format AAAA-MM-JJ.";s:14:"date_too_early";s:34:"La date de ce champ est trop tôt.";s:13:"date_too_late";s:37:"La date de ce champ est trop tardive.";s:14:"invalid_number";s:27:"Veuillez saisir un numéro.";s:16:"number_too_small";s:38:"Le chiffre de ce champ est trop petit.";s:16:"number_too_large";s:32:"Ce champ a un numéro trop long.";s:23:"quiz_answer_not_correct";s:42:"La réponse à la question est incorrecte.";s:13:"invalid_email";s:37:"Veuillez saisir votre adresse e-mail.";s:11:"invalid_url";s:24:"Veuillez saisisr une URL";s:11:"invalid_tel";s:42:"Veuillez saisir un numéro de téléphone.";}'),
(7, 6, '_additional_settings', ''),
(8, 6, '_locale', 'fr_FR'),
(9, 6, '_hash', '7509437c7f5d41221c65f7f1091b17829aac00cc'),
(10, 10, '_edit_last', '1'),
(11, 10, '_edit_lock', '1716388438:1'),
(12, 14, '_wp_attached_file', '2024/05/nathalie-0.webp'),
(13, 14, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:960;s:4:"file";s:23:"2024/05/nathalie-0.webp";s:8:"filesize";i:154822;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-0-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:13146;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-0-1024x683.webp";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:59256;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-0-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:6816;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-0-768x512.webp";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:41006;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 15, '_wp_attached_file', '2024/05/nathalie-1.webp'),
(15, 15, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:960;s:4:"file";s:23:"2024/05/nathalie-1.webp";s:8:"filesize";i:95150;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-1-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:18354;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-1-1024x683.webp";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:101272;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-1-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8012;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-1-768x512.webp";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:69660;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(16, 16, '_wp_attached_file', '2024/05/nathalie-2.webp'),
(17, 16, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:868;s:4:"file";s:23:"2024/05/nathalie-2.webp";s:8:"filesize";i:188022;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-2-300x181.webp";s:5:"width";i:300;s:6:"height";i:181;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:21730;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-2-1024x617.webp";s:5:"width";i:1024;s:6:"height";i:617;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:175422;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-2-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:11010;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-2-768x463.webp";s:5:"width";i:768;s:6:"height";i:463;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:109276;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(18, 17, '_wp_attached_file', '2024/05/nathalie-3.webp'),
(19, 17, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:2160;s:4:"file";s:23:"2024/05/nathalie-3.webp";s:8:"filesize";i:52060;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-3-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7814;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-3-683x1024.webp";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:35658;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-3-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:3828;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-3-768x1152.webp";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:41176;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-3-1024x1536.webp";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:59732;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-3-1365x2048.webp";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:86278;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(20, 18, '_wp_attached_file', '2024/05/nathalie-4.webp'),
(21, 18, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:934;s:6:"height";i:1400;s:4:"file";s:23:"2024/05/nathalie-4.webp";s:8:"filesize";i:114728;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-4-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:18230;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-4-683x1024.webp";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:122592;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-4-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7686;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-4-768x1151.webp";s:5:"width";i:768;s:6:"height";i:1151;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:144912;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(22, 19, '_wp_attached_file', '2024/05/nathalie-5.webp'),
(23, 19, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:935;s:6:"height";i:1400;s:4:"file";s:23:"2024/05/nathalie-5.webp";s:8:"filesize";i:115978;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-5-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:19140;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-5-684x1024.webp";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:126496;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-5-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8136;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-5-768x1150.webp";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:149862;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(24, 20, '_wp_attached_file', '2024/05/nathalie-6.webp'),
(25, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:1152;s:4:"file";s:23:"2024/05/nathalie-6.webp";s:8:"filesize";i:65586;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-6-300x240.webp";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:12740;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-6-1024x819.webp";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:69814;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-6-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:5356;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-6-768x614.webp";s:5:"width";i:768;s:6:"height";i:614;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:46884;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(26, 21, '_wp_attached_file', '2024/05/nathalie-7.webp'),
(27, 21, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:960;s:4:"file";s:23:"2024/05/nathalie-7.webp";s:8:"filesize";i:53120;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-7-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:12128;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-7-1024x683.webp";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:59366;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-7-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:5686;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-7-768x512.webp";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:41540;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(28, 22, '_wp_attached_file', '2024/05/nathalie-8.webp'),
(29, 22, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:2097;s:4:"file";s:23:"2024/05/nathalie-8.webp";s:8:"filesize";i:126538;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-8-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:16060;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-8-684x1024.webp";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:83900;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-8-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8384;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-8-768x1150.webp";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:97722;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-8-1025x1536.webp";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:139900;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-8-1367x2048.webp";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:202766;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(30, 23, '_wp_attached_file', '2024/05/nathalie-9.webp'),
(31, 23, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:960;s:4:"file";s:23:"2024/05/nathalie-9.webp";s:8:"filesize";i:75854;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-9-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:12920;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-9-1024x683.webp";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:78626;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-9-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:6706;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-9-768x512.webp";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:51936;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(32, 24, '_wp_attached_file', '2024/05/nathalie-10.webp'),
(33, 24, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1050;s:4:"file";s:24:"2024/05/nathalie-10.webp";s:8:"filesize";i:339088;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-10-300x225.webp";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:28034;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-10-1024x768.webp";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:269410;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-10-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:10182;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-10-768x576.webp";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:157094;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(34, 25, '_wp_attached_file', '2024/05/nathalie-11.webp'),
(35, 25, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:961;s:4:"file";s:24:"2024/05/nathalie-11.webp";s:8:"filesize";i:51870;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-11-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:13298;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-11-1024x683.webp";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:58122;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-11-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:6840;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-11-768x513.webp";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:42194;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(36, 26, '_wp_attached_file', '2024/05/nathalie-12.webp'),
(37, 26, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:960;s:4:"file";s:24:"2024/05/nathalie-12.webp";s:8:"filesize";i:88062;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-12-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:18652;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-12-1024x683.webp";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:93212;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-12-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:9384;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-12-768x512.webp";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:64474;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(38, 27, '_wp_attached_file', '2024/05/nathalie-13.webp'),
(39, 27, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:1440;s:4:"file";s:24:"2024/05/nathalie-13.webp";s:8:"filesize";i:36440;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-13-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8486;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-13-683x1024.webp";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:40490;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-13-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:4738;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-13-768x1152.webp";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:46552;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(40, 28, '_wp_attached_file', '2024/05/nathalie-14.webp'),
(41, 28, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:1440;s:4:"file";s:24:"2024/05/nathalie-14.webp";s:8:"filesize";i:74078;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-14-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:9946;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-14-683x1024.webp";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:74434;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-14-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:4846;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-14-768x1152.webp";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:85990;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(42, 29, '_wp_attached_file', '2024/05/nathalie-15.webp'),
(43, 29, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:962;s:6:"height";i:1440;s:4:"file";s:24:"2024/05/nathalie-15.webp";s:8:"filesize";i:117198;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-15-200x300.webp";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:19460;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-15-684x1024.webp";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:123352;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-15-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8168;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-15-768x1150.webp";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:144470;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(44, 30, '_edit_lock', '1716461706:1'),
(45, 14, '_wp_attachment_image_alt', 'santé !'),
(46, 30, '_edit_last', '1'),
(47, 30, 'Type', 'argentique'),
(48, 30, '_Type', 'field_664c9081b2c30'),
(49, 30, 'reference', 'bf2385'),
(50, 30, '_reference', 'field_664c9137b2c31'),
(51, 30, 'annee', '2019'),
(52, 30, '_annee', 'field_664c9307b2c32'),
(53, 31, '_edit_lock', '1716461673:1'),
(54, 15, '_wp_attachment_image_alt', 'Et bon anniversaire'),
(55, 31, '_edit_last', '1'),
(56, 31, 'Type', 'argentique'),
(57, 31, '_Type', 'field_664c9081b2c30'),
(58, 31, 'reference', 'bf2386'),
(59, 31, '_reference', 'field_664c9137b2c31'),
(60, 31, 'annee', '2020'),
(61, 31, '_annee', 'field_664c9307b2c32'),
(62, 32, '_edit_lock', '1716461626:1'),
(63, 16, '_wp_attachment_image_alt', 'let\'s party'),
(64, 32, '_edit_last', '1'),
(65, 32, 'Type', 'numerique'),
(66, 32, '_Type', 'field_664c9081b2c30'),
(67, 32, 'reference', 'bf2387'),
(68, 32, '_reference', 'field_664c9137b2c31'),
(69, 32, 'annee', '2021'),
(70, 32, '_annee', 'field_664c9307b2c32'),
(71, 8, '_edit_lock', '1716386817:1'),
(72, 9, '_edit_lock', '1716380882:1'),
(73, 33, '_wp_attached_file', '2024/05/Logo.png'),
(74, 33, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:690;s:6:"height";i:44;s:4:"file";s:16:"2024/05/Logo.png";s:8:"filesize";i:3547;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:15:"Logo-300x19.png";s:5:"width";i:300;s:6:"height";i:19;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2636;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"Logo-150x44.png";s:5:"width";i:150;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:507;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(75, 34, '_wp_attached_file', '2024/05/cropped-Logo.png'),
(76, 34, '_wp_attachment_context', 'custom-logo'),
(77, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:690;s:6:"height";i:44;s:4:"file";s:24:"2024/05/cropped-Logo.png";s:8:"filesize";i:3679;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:23:"cropped-Logo-300x19.png";s:5:"width";i:300;s:6:"height";i:19;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2636;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"cropped-Logo-150x44.png";s:5:"width";i:150;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:507;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(78, 35, '_wp_attached_file', '2024/05/cropped-Logo-1.png'),
(79, 35, '_wp_attachment_context', 'site-icon'),
(80, 35, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:26:"2024/05/cropped-Logo-1.png";s:8:"filesize";i:4792;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"cropped-Logo-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4181;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"cropped-Logo-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2685;}s:13:"site_icon-270";a:5:{s:4:"file";s:26:"cropped-Logo-1-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3888;}s:13:"site_icon-192";a:5:{s:4:"file";s:26:"cropped-Logo-1-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3042;}s:13:"site_icon-180";a:5:{s:4:"file";s:26:"cropped-Logo-1-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2944;}s:12:"site_icon-32";a:5:{s:4:"file";s:24:"cropped-Logo-1-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:680;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(81, 36, '_edit_lock', '1716298632:1'),
(82, 36, '_wp_trash_meta_status', 'publish'),
(83, 36, '_wp_trash_meta_time', '1716298647'),
(84, 37, '_edit_lock', '1717234814:1'),
(85, 39, '_edit_lock', '1717237841:1'),
(86, 41, '_edit_lock', '1716299392:1'),
(87, 43, '_edit_lock', '1717769520:1'),
(88, 2, '_wp_trash_meta_status', 'publish'),
(89, 2, '_wp_trash_meta_time', '1716299571'),
(90, 2, '_wp_desired_post_slug', 'sample-page'),
(91, 3, '_wp_trash_meta_status', 'draft'),
(92, 3, '_wp_trash_meta_time', '1716299575'),
(93, 3, '_wp_desired_post_slug', 'privacy-policy'),
(94, 47, '_menu_item_type', 'custom'),
(95, 47, '_menu_item_menu_item_parent', '0'),
(96, 47, '_menu_item_object_id', '47'),
(97, 47, '_menu_item_object', 'custom'),
(98, 47, '_menu_item_target', ''),
(99, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(100, 47, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(101, 47, '_menu_item_url', '#'),
(103, 48, '_menu_item_type', 'post_type'),
(104, 48, '_menu_item_menu_item_parent', '0'),
(105, 48, '_menu_item_object_id', '39'),
(106, 48, '_menu_item_object', 'page'),
(107, 48, '_menu_item_target', ''),
(108, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(109, 48, '_menu_item_xfn', ''),
(110, 48, '_menu_item_url', ''),
(112, 49, '_menu_item_type', 'post_type'),
(113, 49, '_menu_item_menu_item_parent', '0'),
(114, 49, '_menu_item_object_id', '37'),
(115, 49, '_menu_item_object', 'page'),
(116, 49, '_menu_item_target', ''),
(117, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(118, 49, '_menu_item_xfn', ''),
(119, 49, '_menu_item_url', ''),
(121, 50, '_wp_trash_meta_status', 'publish'),
(122, 50, '_wp_trash_meta_time', '1716299965'),
(125, 53, '_edit_lock', '1716461579:1'),
(126, 17, '_wp_attachment_image_alt', 'Tout est installé'),
(128, 53, '_edit_last', '1'),
(129, 53, 'Type', 'argentique'),
(130, 53, '_Type', 'field_664c9081b2c30'),
(131, 53, 'reference', 'bf2388'),
(132, 53, '_reference', 'field_664c9137b2c31'),
(133, 53, 'annee', '2019'),
(134, 53, '_annee', 'field_664c9307b2c32'),
(135, 54, '_edit_lock', '1716461550:1'),
(136, 18, '_wp_attachment_image_alt', 'Vers l\'éternité'),
(137, 54, '_edit_last', '1'),
(138, 54, 'Type', 'numerique'),
(139, 54, '_Type', 'field_664c9081b2c30'),
(140, 54, 'reference', 'bf2389'),
(141, 54, '_reference', 'field_664c9137b2c31'),
(142, 54, 'annee', '2020'),
(143, 54, '_annee', 'field_664c9307b2c32'),
(144, 55, '_edit_lock', '1716461512:1'),
(145, 19, '_wp_attachment_image_alt', 'Embrassez la mariée'),
(146, 55, '_edit_last', '1'),
(147, 55, 'Type', 'numerique'),
(148, 55, '_Type', 'field_664c9081b2c30'),
(149, 55, 'reference', 'bf2390'),
(150, 55, '_reference', 'field_664c9137b2c31'),
(151, 55, 'annee', '2021'),
(152, 55, '_annee', 'field_664c9307b2c32'),
(153, 56, '_edit_lock', '1716461471:1'),
(154, 20, '_wp_attachment_image_alt', 'Dansons ensemble'),
(155, 56, '_edit_last', '1'),
(156, 56, 'Type', 'argentique'),
(157, 56, '_Type', 'field_664c9081b2c30'),
(158, 56, 'reference', 'bf2391'),
(159, 56, '_reference', 'field_664c9137b2c31'),
(160, 56, 'annee', '2020'),
(161, 56, '_annee', 'field_664c9307b2c32'),
(162, 8, '_edit_last', '1'),
(163, 57, '_edit_lock', '1716461428:1'),
(164, 21, '_wp_attachment_image_alt', 'Le menu'),
(165, 57, '_edit_last', '1'),
(166, 57, 'Type', 'numerique'),
(167, 57, '_Type', 'field_664c9081b2c30'),
(168, 57, 'reference', 'bf2392'),
(169, 57, '_reference', 'field_664c9137b2c31'),
(170, 57, 'annee', '2019'),
(171, 57, '_annee', 'field_664c9307b2c32'),
(172, 58, '_edit_lock', '1716461374:1'),
(173, 22, '_wp_attachment_image_alt', 'Au bal masqué'),
(174, 58, '_edit_last', '1'),
(175, 58, 'Type', 'numerique'),
(176, 58, '_Type', 'field_664c9081b2c30'),
(177, 58, 'reference', 'bf2393'),
(178, 58, '_reference', 'field_664c9137b2c31'),
(179, 58, 'annee', '2021'),
(180, 58, '_annee', 'field_664c9307b2c32'),
(181, 59, '_edit_lock', '1716461457:1'),
(182, 23, '_wp_attachment_image_alt', 'Let\'s dance!'),
(183, 59, '_edit_last', '1'),
(184, 59, 'Type', 'numerique'),
(185, 59, '_Type', 'field_664c9081b2c30'),
(186, 59, 'reference', 'bf2394'),
(187, 59, '_reference', 'field_664c9137b2c31'),
(188, 59, 'annee', '2022'),
(189, 59, '_annee', 'field_664c9307b2c32'),
(190, 60, '_edit_lock', '1716461284:1'),
(191, 24, '_wp_attachment_image_alt', 'Jour de match'),
(192, 60, '_edit_last', '1'),
(193, 60, 'Type', 'numerique'),
(194, 60, '_Type', 'field_664c9081b2c30'),
(195, 60, 'reference', 'bf2395'),
(196, 60, '_reference', 'field_664c9137b2c31'),
(197, 60, 'annee', '2022'),
(198, 60, '_annee', 'field_664c9307b2c32'),
(199, 61, '_edit_lock', '1716461252:1'),
(200, 25, '_wp_attachment_image_alt', 'Préparation'),
(201, 61, '_edit_last', '1'),
(202, 61, 'Type', 'argentique'),
(203, 61, '_Type', 'field_664c9081b2c30'),
(204, 61, 'reference', 'bf2396'),
(205, 61, '_reference', 'field_664c9137b2c31'),
(206, 61, 'annee', '2022') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(207, 61, '_annee', 'field_664c9307b2c32'),
(208, 62, '_edit_lock', '1717589210:1'),
(209, 26, '_wp_attachment_image_alt', 'Bière ou eau plate ?'),
(210, 62, '_edit_last', '1'),
(211, 62, 'Type', 'numerique'),
(212, 62, '_Type', 'field_664c9081b2c30'),
(213, 62, 'reference', 'bf2397'),
(214, 62, '_reference', 'field_664c9137b2c31'),
(215, 62, 'annee', '2022'),
(216, 62, '_annee', 'field_664c9307b2c32'),
(217, 63, '_edit_lock', '1716461200:1'),
(218, 27, '_wp_attachment_image_alt', 'Bouquet final'),
(219, 63, '_edit_last', '1'),
(220, 63, 'Type', 'numerique'),
(221, 63, '_Type', 'field_664c9081b2c30'),
(222, 63, 'reference', 'bf2398'),
(223, 63, '_reference', 'field_664c9137b2c31'),
(224, 63, 'annee', '2022'),
(225, 63, '_annee', 'field_664c9307b2c32'),
(226, 64, '_edit_lock', '1716461175:1'),
(227, 28, '_wp_attachment_image_alt', 'Du soir au matin'),
(228, 64, '_edit_last', '1'),
(229, 64, 'Type', 'argentique'),
(230, 64, '_Type', 'field_664c9081b2c30'),
(231, 64, 'reference', 'bf2399'),
(232, 64, '_reference', 'field_664c9137b2c31'),
(233, 64, 'annee', '2022'),
(234, 64, '_annee', 'field_664c9307b2c32'),
(235, 65, '_edit_lock', '1716969027:1'),
(236, 29, '_wp_attachment_image_alt', 'Team mariée'),
(237, 65, '_edit_last', '1'),
(238, 65, 'Type', 'numerique'),
(239, 65, '_Type', 'field_664c9081b2c30'),
(240, 65, 'reference', 'bf2400'),
(241, 65, '_reference', 'field_664c9137b2c31'),
(242, 65, 'annee', '2022'),
(243, 65, '_annee', 'field_664c9307b2c32'),
(244, 65, '_wp_old_date', '2024-05-22'),
(245, 63, '_wp_old_date', '2024-05-22'),
(246, 64, '_wp_old_date', '2024-05-22'),
(247, 62, '_wp_old_date', '2024-05-22'),
(248, 61, '_wp_old_date', '2024-05-22'),
(249, 60, '_wp_old_date', '2024-05-22'),
(250, 59, '_wp_old_date', '2024-05-22'),
(251, 58, '_wp_old_date', '2024-05-22'),
(252, 57, '_wp_old_date', '2024-05-22'),
(253, 56, '_wp_old_date', '2024-05-22'),
(254, 55, '_wp_old_date', '2024-05-22'),
(255, 54, '_wp_old_date', '2024-05-22'),
(256, 53, '_wp_old_date', '2024-05-22'),
(258, 32, '_wp_old_date', '2024-05-21'),
(259, 31, '_wp_old_date', '2024-05-21'),
(260, 30, '_wp_old_date', '2024-05-21'),
(261, 8, '_wp_trash_meta_status', 'publish'),
(262, 8, '_wp_trash_meta_time', '1716392331'),
(263, 8, '_wp_desired_post_slug', 'taxonomy_664c903d61cf5'),
(264, 7, '_edit_lock', '1716392399:1'),
(265, 71, '_edit_last', '1'),
(266, 71, '_edit_lock', '1716393452:1'),
(267, 71, '_wp_trash_meta_status', 'publish'),
(268, 71, '_wp_trash_meta_time', '1716393645'),
(269, 71, '_wp_desired_post_slug', 'taxonomy_664e12676aa72'),
(270, 72, '_edit_lock', '1716393884:1'),
(271, 73, '_wp_trash_meta_status', 'publish'),
(272, 73, '_wp_trash_meta_time', '1716467876'),
(273, 74, '_menu_item_type', 'post_type'),
(274, 74, '_menu_item_menu_item_parent', '0'),
(275, 74, '_menu_item_object_id', '43'),
(276, 74, '_menu_item_object', 'page'),
(277, 74, '_menu_item_target', ''),
(278, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(279, 74, '_menu_item_xfn', ''),
(280, 74, '_menu_item_url', ''),
(282, 75, '_menu_item_type', 'post_type'),
(283, 75, '_menu_item_menu_item_parent', '0'),
(284, 75, '_menu_item_object_id', '41'),
(285, 75, '_menu_item_object', 'page'),
(286, 75, '_menu_item_target', ''),
(287, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(288, 75, '_menu_item_xfn', ''),
(289, 75, '_menu_item_url', ''),
(291, 76, '_menu_item_type', 'post_type'),
(292, 76, '_menu_item_menu_item_parent', '0'),
(293, 76, '_menu_item_object_id', '37'),
(294, 76, '_menu_item_object', 'page'),
(295, 76, '_menu_item_target', ''),
(296, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(297, 76, '_menu_item_xfn', ''),
(298, 76, '_menu_item_url', ''),
(302, 1, '_wp_trash_meta_status', 'publish'),
(303, 1, '_wp_trash_meta_time', '1717234984'),
(304, 1, '_wp_desired_post_slug', 'hello-world'),
(305, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(306, 81, '_edit_lock', '1717236635:1'),
(307, 81, '_wp_trash_meta_status', 'publish'),
(308, 81, '_wp_trash_meta_time', '1717236653'),
(309, 49, '_wp_old_date', '2024-05-21'),
(310, 48, '_wp_old_date', '2024-05-21'),
(311, 47, '_wp_old_date', '2024-05-21') ;

#
# Fin du contenu des données de la table `wp_postmeta`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Structure de la table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-05-21 10:20:22', '2024-05-21 10:20:22', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2024-06-01 09:43:04', '2024-06-01 09:43:04', '', 0, 'http://motaphotographie.local/?p=1', 0, 'post', '', 1),
(2, 1, '2024-05-21 10:20:22', '2024-05-21 10:20:22', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://motaphotographie.local/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2024-05-21 13:52:51', '2024-05-21 13:52:51', '', 0, 'http://motaphotographie.local/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-05-21 10:20:22', '2024-05-21 10:20:22', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://motaphotographie.local.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2024-05-21 13:52:55', '2024-05-21 13:52:55', '', 0, 'http://motaphotographie.local/?page_id=3', 0, 'page', '', 0),
(5, 1, '2024-05-21 10:21:43', '2024-05-21 10:21:43', '<!-- wp:page-list /-->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-05-21 10:21:43', '2024-05-21 10:21:43', '', 0, 'http://motaphotographie.local/navigation/', 0, 'wp_navigation', '', 0),
(6, 1, '2024-05-21 12:06:08', '2024-05-21 12:06:08', '<div class="F-Nom">\r\n  <label> Nom\r\n    [text* your-name autocomplete:name] </label>\r\n</div>\r\n<div class="F-Email">\r\n <label> E-mail\r\n    [email* your-email autocomplete:email] </label>\r\n</div>\r\n<div class="F-reference">\r\n <label> Réf. PPHOTO\r\n    [text* your-photo] </label>\r\n</div>\r\n<div class="F-message">\r\n <label> MESSAGE (optional)\r\n    [textarea your-message] </label>\r\n</div>\r\n<div class="F-button">\r\n [submit "Envoyer"]\r\n</div>\n1\n[_site_title] "[your-subject]"\n[_site_title] <wordpress@motaphotographie.local>\n[_site_admin_email]\nFrom: [your-name] [your-email]\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis is a notification that a contact form was submitted on your website ([_site_title] [_site_url]).\nReply-To: [your-email]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <wordpress@motaphotographie.local>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.\nVeuillez saisir une date au format AAAA-MM-JJ.\nLa date de ce champ est trop tôt.\nLa date de ce champ est trop tardive.\nVeuillez saisir un numéro.\nLe chiffre de ce champ est trop petit.\nCe champ a un numéro trop long.\nLa réponse à la question est incorrecte.\nVeuillez saisir votre adresse e-mail.\nVeuillez saisisr une URL\nVeuillez saisir un numéro de téléphone.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2024-05-21 14:09:58', '2024-05-21 14:09:58', '', 0, 'http://motaphotographie.local/?post_type=wpcf7_contact_form&#038;p=6', 0, 'wpcf7_contact_form', '', 0),
(7, 1, '2024-05-21 12:14:53', '2024-05-21 12:14:53', 'a:35:{s:9:"post_type";s:13:"photographies";s:22:"advanced_configuration";b:1;s:13:"import_source";s:5:"cptui";s:11:"import_date";i:1716293693;s:6:"labels";a:35:{s:4:"name";s:13:"Photographies";s:13:"singular_name";s:12:"Photographie";s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:8:"archives";s:0:"";s:10:"attributes";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:14:"filter_by_date";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:14:"item_published";s:0:"";s:24:"item_published_privately";s:0:"";s:22:"item_reverted_to_draft";s:0:"";s:14:"item_scheduled";s:0:"";s:12:"item_updated";s:0:"";s:9:"item_link";s:0:"";s:21:"item_link_description";s:0:"";s:14:"name_admin_bar";s:0:"";s:12:"item_trashed";s:0:"";}s:11:"description";s:0:"";s:6:"public";b:1;s:12:"hierarchical";b:0;s:19:"exclude_from_search";b:0;s:18:"publicly_queryable";b:1;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"admin_menu_parent";s:0:"";s:17:"show_in_admin_bar";b:1;s:17:"show_in_nav_menus";b:1;s:12:"show_in_rest";b:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:0:"";s:21:"rest_controller_class";s:0:"";s:13:"menu_position";s:0:"";s:9:"menu_icon";N;s:19:"rename_capabilities";b:0;s:24:"singular_capability_name";s:4:"post";s:22:"plural_capability_name";s:5:"posts";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:11:"has_archive";b:0;s:16:"has_archive_slug";s:0:"";s:7:"rewrite";a:5:{s:17:"permalink_rewrite";s:13:"post_type_key";s:4:"slug";s:0:"";s:5:"feeds";b:0;s:5:"pages";b:1;s:10:"with_front";b:1;}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:10:"can_export";b:0;s:16:"delete_with_user";b:0;s:20:"register_meta_box_cb";N;s:16:"enter_title_here";s:0:"";}', 'Photographies', 'photographies', 'publish', 'closed', 'closed', '', 'post_type_664c903d58458', '', '', '2024-05-21 12:14:53', '2024-05-21 12:14:53', '', 0, 'http://motaphotographie.local/?post_type=acf-post-type&p=7', 0, 'acf-post-type', '', 0),
(8, 1, '2024-05-21 12:14:53', '2024-05-21 12:14:53', 'a:29:{s:8:"taxonomy";s:10:"categories";s:11:"object_type";a:1:{i:0;s:13:"photographies";}s:22:"advanced_configuration";i:1;s:13:"import_source";s:5:"cptui";s:11:"import_date";i:1716293693;s:6:"labels";a:25:{s:4:"name";s:12:"catégories ";s:13:"singular_name";s:11:"catégorie ";s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:22:"name_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:22:"desc_field_description";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:13:"back_to_items";s:0:"";s:9:"item_link";s:0:"";s:21:"item_link_description";s:0:"";}s:11:"description";s:35:"événement a l\'origine du cliché.";s:12:"capabilities";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:6:"public";i:1;s:18:"publicly_queryable";i:1;s:12:"hierarchical";i:0;s:7:"show_ui";i:1;s:12:"show_in_menu";i:1;s:17:"show_in_nav_menus";i:1;s:12:"show_in_rest";i:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:0:"";s:21:"rest_controller_class";s:0:"";s:13:"show_tagcloud";i:0;s:18:"show_in_quick_edit";i:1;s:17:"show_admin_column";i:0;s:7:"rewrite";a:3:{s:17:"permalink_rewrite";s:12:"taxonomy_key";s:10:"with_front";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:12:"default_term";a:1:{s:20:"default_term_enabled";s:1:"0";}s:4:"sort";i:0;s:8:"meta_box";s:7:"default";s:11:"meta_box_cb";s:0:"";s:20:"meta_box_sanitize_cb";s:0:"";}', 'catégories', 'categories', 'trash', 'closed', 'closed', '', 'taxonomy_664c903d61cf5__trashed', '', '', '2024-05-22 15:38:51', '2024-05-22 15:38:51', '', 0, 'http://motaphotographie.local/?post_type=acf-taxonomy&#038;p=8', 0, 'acf-taxonomy', '', 0),
(9, 1, '2024-05-21 12:14:53', '2024-05-21 12:14:53', 'a:29:{s:8:"taxonomy";s:7:"formats";s:11:"object_type";a:1:{i:0;s:13:"photographies";}s:22:"advanced_configuration";b:1;s:13:"import_source";s:5:"cptui";s:11:"import_date";i:1716393967;s:6:"labels";a:29:{s:13:"singular_name";s:6:"format";s:4:"name";s:7:"formats";s:9:"menu_name";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:9:"all_items";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:22:"name_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:24:"parent_field_description";s:0:"";s:22:"desc_field_description";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:14:"filter_by_item";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:9:"most_used";s:0:"";s:13:"back_to_items";s:0:"";s:9:"item_link";s:0:"";s:21:"item_link_description";s:0:"";}s:11:"description";s:0:"";s:12:"capabilities";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:6:"public";b:1;s:18:"publicly_queryable";b:1;s:12:"hierarchical";b:0;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"show_in_nav_menus";b:1;s:12:"show_in_rest";b:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:0:"";s:21:"rest_controller_class";s:0:"";s:13:"show_tagcloud";b:0;s:18:"show_in_quick_edit";s:0:"";s:17:"show_admin_column";b:0;s:7:"rewrite";a:4:{s:17:"permalink_rewrite";s:12:"taxonomy_key";s:4:"slug";s:0:"";s:10:"with_front";b:1;s:20:"rewrite_hierarchical";b:0;}s:9:"query_var";s:12:"taxonomy_key";s:14:"query_var_name";s:0:"";s:12:"default_term";a:4:{s:20:"default_term_enabled";b:0;s:17:"default_term_name";s:0:"";s:17:"default_term_slug";s:0:"";s:24:"default_term_description";s:0:"";}s:4:"sort";b:0;s:8:"meta_box";s:7:"default";s:11:"meta_box_cb";s:0:"";s:20:"meta_box_sanitize_cb";s:0:"";}', 'formats', 'formats', 'publish', 'closed', 'closed', '', 'taxonomy_664c903d6416f', '', '', '2024-05-22 16:06:07', '2024-05-22 16:06:07', '', 0, 'http://motaphotographie.local/?post_type=acf-taxonomy&#038;p=9', 0, 'acf-taxonomy', '', 0),
(10, 1, '2024-05-21 12:27:50', '2024-05-21 12:27:50', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:13:"photographies";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Details photo', 'details-photo', 'publish', 'closed', 'closed', '', 'group_664c908137dcd', '', '', '2024-05-22 12:26:03', '2024-05-22 12:26:03', '', 0, 'http://motaphotographie.local/?post_type=acf-field-group&#038;p=10', 0, 'acf-field-group', '', 0),
(11, 1, '2024-05-21 12:27:50', '2024-05-21 12:27:50', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"radio";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:10:"argentique";s:10:"Argentique";s:9:"numerique";s:10:"Numérique";}s:13:"default_value";s:0:"";s:13:"return_format";s:5:"label";s:10:"allow_null";i:0;s:12:"other_choice";i:0;s:6:"layout";s:8:"vertical";s:17:"save_other_choice";i:0;}', 'Type de photo', 'Type', 'publish', 'closed', 'closed', '', 'field_664c9081b2c30', '', '', '2024-05-22 12:26:03', '2024-05-22 12:26:03', '', 10, 'http://motaphotographie.local/?post_type=acf-field&#038;p=11', 0, 'acf-field', '', 0),
(12, 1, '2024-05-21 12:27:50', '2024-05-21 12:27:50', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:6:"bf2300";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'référence', 'reference', 'publish', 'closed', 'closed', '', 'field_664c9137b2c31', '', '', '2024-05-21 12:27:50', '2024-05-21 12:27:50', '', 10, 'http://motaphotographie.local/?post_type=acf-field&p=12', 1, 'acf-field', '', 0),
(13, 1, '2024-05-21 12:27:50', '2024-05-21 12:27:50', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:2020;s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'année', 'annee', 'publish', 'closed', 'closed', '', 'field_664c9307b2c32', '', '', '2024-05-21 12:27:50', '2024-05-21 12:27:50', '', 10, 'http://motaphotographie.local/?post_type=acf-field&p=13', 2, 'acf-field', '', 0),
(14, 1, '2024-05-21 12:52:07', '2024-05-21 12:52:07', '', 'nathalie-0', '', 'inherit', 'open', 'closed', '', 'nathalie-0', '', '', '2024-05-21 12:57:11', '2024-05-21 12:57:11', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-0.webp', 0, 'attachment', 'image/webp', 0),
(15, 1, '2024-05-21 12:52:07', '2024-05-21 12:52:07', '', 'nathalie-1', '', 'inherit', 'open', 'closed', '', 'nathalie-1', '', '', '2024-05-21 13:14:31', '2024-05-21 13:14:31', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-1.webp', 0, 'attachment', 'image/webp', 0),
(16, 1, '2024-05-21 12:52:08', '2024-05-21 12:52:08', '', 'nathalie-2', '', 'inherit', 'open', 'closed', '', 'nathalie-2', '', '', '2024-05-21 13:16:46', '2024-05-21 13:16:46', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-2.webp', 0, 'attachment', 'image/webp', 0),
(17, 1, '2024-05-21 12:52:09', '2024-05-21 12:52:09', '', 'nathalie-3', '', 'inherit', 'open', 'closed', '', 'nathalie-3', '', '', '2024-05-22 12:14:43', '2024-05-22 12:14:43', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-3.webp', 0, 'attachment', 'image/webp', 0),
(18, 1, '2024-05-21 12:52:10', '2024-05-21 12:52:10', '', 'nathalie-4', '', 'inherit', 'open', 'closed', '', 'nathalie-4', '', '', '2024-05-22 12:18:44', '2024-05-22 12:18:44', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-4.webp', 0, 'attachment', 'image/webp', 0),
(19, 1, '2024-05-21 12:52:10', '2024-05-21 12:52:10', '', 'nathalie-5', '', 'inherit', 'open', 'closed', '', 'nathalie-5', '', '', '2024-05-22 12:21:44', '2024-05-22 12:21:44', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-5.webp', 0, 'attachment', 'image/webp', 0),
(20, 1, '2024-05-21 12:52:11', '2024-05-21 12:52:11', '', 'nathalie-6', '', 'inherit', 'open', 'closed', '', 'nathalie-6', '', '', '2024-05-22 12:22:48', '2024-05-22 12:22:48', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-6.webp', 0, 'attachment', 'image/webp', 0),
(21, 1, '2024-05-21 12:52:12', '2024-05-21 12:52:12', '', 'nathalie-7', '', 'inherit', 'open', 'closed', '', 'nathalie-7', '', '', '2024-05-22 12:34:46', '2024-05-22 12:34:46', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-7.webp', 0, 'attachment', 'image/webp', 0),
(22, 1, '2024-05-21 12:52:12', '2024-05-21 12:52:12', '', 'nathalie-8', '', 'inherit', 'open', 'closed', '', 'nathalie-8', '', '', '2024-05-22 12:36:21', '2024-05-22 12:36:21', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-8.webp', 0, 'attachment', 'image/webp', 0),
(23, 1, '2024-05-21 12:52:13', '2024-05-21 12:52:13', '', 'nathalie-9', '', 'inherit', 'open', 'closed', '', 'nathalie-9', '', '', '2024-05-22 12:38:33', '2024-05-22 12:38:33', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-9.webp', 0, 'attachment', 'image/webp', 0),
(24, 1, '2024-05-21 12:52:14', '2024-05-21 12:52:14', '', 'nathalie-10', '', 'inherit', 'open', 'closed', '', 'nathalie-10', '', '', '2024-05-22 12:39:58', '2024-05-22 12:39:58', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-10.webp', 0, 'attachment', 'image/webp', 0),
(25, 1, '2024-05-21 12:52:14', '2024-05-21 12:52:14', '', 'nathalie-11', '', 'inherit', 'open', 'closed', '', 'nathalie-11', '', '', '2024-05-22 12:41:46', '2024-05-22 12:41:46', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-11.webp', 0, 'attachment', 'image/webp', 0),
(26, 1, '2024-05-21 12:52:15', '2024-05-21 12:52:15', '', 'nathalie-12', '', 'inherit', 'open', 'closed', '', 'nathalie-12', '', '', '2024-05-22 12:43:13', '2024-05-22 12:43:13', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-12.webp', 0, 'attachment', 'image/webp', 0),
(27, 1, '2024-05-21 12:52:15', '2024-05-21 12:52:15', '', 'nathalie-13', '', 'inherit', 'open', 'closed', '', 'nathalie-13', '', '', '2024-05-22 12:44:52', '2024-05-22 12:44:52', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-13.webp', 0, 'attachment', 'image/webp', 0),
(28, 1, '2024-05-21 12:52:16', '2024-05-21 12:52:16', '', 'nathalie-14', '', 'inherit', 'open', 'closed', '', 'nathalie-14', '', '', '2024-05-22 12:46:09', '2024-05-22 12:46:09', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-14.webp', 0, 'attachment', 'image/webp', 0),
(29, 1, '2024-05-21 12:52:16', '2024-05-21 12:52:16', '', 'nathalie-15', '', 'inherit', 'open', 'closed', '', 'nathalie-15', '', '', '2024-05-22 12:47:43', '2024-05-22 12:47:43', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-15.webp', 0, 'attachment', 'image/webp', 0),
(30, 1, '2019-05-21 13:13:00', '2019-05-21 13:13:00', '<!-- wp:image {"id":14,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-0-1024x683.webp" alt="santé !" class="wp-image-14"/></figure>\n<!-- /wp:image -->', 'Santé !', '', 'publish', 'closed', 'closed', '', 'sante', '', '', '2024-05-23 10:55:06', '2024-05-23 10:55:06', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=30', 0, 'photographies', '', 0),
(31, 1, '2020-05-21 13:15:00', '2020-05-21 13:15:00', '<!-- wp:image {"id":15,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-1-1024x683.webp" alt="Et bon anniversaire " class="wp-image-15"/></figure>\n<!-- /wp:image -->', 'Et bon anniversaire !', '', 'publish', 'closed', 'closed', '', 'et-bon-anniversaire', '', '', '2024-05-23 10:54:33', '2024-05-23 10:54:33', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=31', 0, 'photographies', '', 0),
(32, 1, '2021-05-21 13:18:00', '2021-05-21 13:18:00', '<!-- wp:image {"id":16,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-2-1024x617.webp" alt="let\'s party " class="wp-image-16"/></figure>\n<!-- /wp:image -->', 'Let\'s party', '', 'publish', 'closed', 'closed', '', 'lets-party', '', '', '2024-05-23 10:53:46', '2024-05-23 10:53:46', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=32', 0, 'photographies', '', 0),
(33, 1, '2024-05-21 13:35:50', '2024-05-21 13:35:50', '', 'Logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2024-05-21 13:35:50', '2024-05-21 13:35:50', '', 0, 'http://motaphotographie.local/wp-content/uploads/2024/05/Logo.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2024-05-21 13:36:12', '2024-05-21 13:36:12', 'http://motaphotographie.local/wp-content/uploads/2024/05/cropped-Logo.png', 'cropped-Logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-png', '', '', '2024-05-21 13:36:12', '2024-05-21 13:36:12', '', 33, 'http://motaphotographie.local/wp-content/uploads/2024/05/cropped-Logo.png', 0, 'attachment', 'image/png', 0),
(35, 1, '2024-05-21 13:36:53', '2024-05-21 13:36:53', 'http://motaphotographie.local/wp-content/uploads/2024/05/cropped-Logo-1.png', 'cropped-Logo-1.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-1-png', '', '', '2024-05-21 13:36:53', '2024-05-21 13:36:53', '', 33, 'http://motaphotographie.local/wp-content/uploads/2024/05/cropped-Logo-1.png', 0, 'attachment', 'image/png', 0),
(36, 1, '2024-05-21 13:37:27', '2024-05-21 13:37:27', '{"site_icon":{"value":35,"type":"option","user_id":1,"date_modified_gmt":"2024-05-21 13:37:12"},"motaphotographie::custom_logo":{"value":34,"type":"theme_mod","user_id":1,"date_modified_gmt":"2024-05-21 13:37:12"},"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2024-05-21 13:37:27"}}', '', '', 'trash', 'closed', 'closed', '', 'c34d5eba-94d1-49b8-a093-ecc7f5d8ec32', '', '', '2024-05-21 13:37:27', '2024-05-21 13:37:27', '', 0, 'http://motaphotographie.local/?p=36', 0, 'customize_changeset', '', 0),
(37, 1, '2024-05-21 13:50:57', '2024-05-21 13:50:57', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2024-06-01 09:22:05', '2024-06-01 09:22:05', '', 0, 'http://motaphotographie.local/?page_id=37', 0, 'page', '', 0),
(38, 1, '2024-05-21 13:50:57', '2024-05-21 13:50:57', '', 'Accueil', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2024-05-21 13:50:57', '2024-05-21 13:50:57', '', 37, 'http://motaphotographie.local/?p=38', 0, 'revision', '', 0),
(39, 1, '2024-05-21 13:51:44', '2024-05-21 13:51:44', '', 'A propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2024-05-21 13:51:44', '2024-05-21 13:51:44', '', 0, 'http://motaphotographie.local/?page_id=39', 0, 'page', '', 0),
(40, 1, '2024-05-21 13:51:44', '2024-05-21 13:51:44', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2024-05-21 13:51:44', '2024-05-21 13:51:44', '', 39, 'http://motaphotographie.local/?p=40', 0, 'revision', '', 0),
(41, 1, '2024-05-21 13:52:14', '2024-05-21 13:52:14', '', 'Mention légales', '', 'publish', 'closed', 'closed', '', 'mention-legales', '', '', '2024-05-21 13:52:14', '2024-05-21 13:52:14', '', 0, 'http://motaphotographie.local/?page_id=41', 0, 'page', '', 0),
(42, 1, '2024-05-21 13:52:14', '2024-05-21 13:52:14', '', 'Mention légales', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2024-05-21 13:52:14', '2024-05-21 13:52:14', '', 41, 'http://motaphotographie.local/?p=42', 0, 'revision', '', 0),
(43, 1, '2024-05-21 13:52:44', '2024-05-21 13:52:44', '<!-- wp:heading -->\n<h2 class="wp-block-heading"><strong>Données personnelles</strong></h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous effectuons un traitement de données personnelles destiné à l’exécution des commandes passées sur notre site Internet et à la gestion de la relation avec nos clients. Ce traitement est&nbsp;nécessaire à l’exécution de mesures précontractuelles prises à votre demande et à l’exécution du contrat conclu entre nous. Il est fondé sur l’article 6, paragraphe 1, point b), du règlement général sur la protection des données (règlement UE 2016/679 du Parlement européen et du Conseil du 27 avril 2016 – RGPD).&nbsp;La demande de données conditionne la conclusion du contrat. Elle&nbsp;a un caractère contractuel. La personne concernée est&nbsp;tenue de fournir les données. À défaut, elle ne pourra pas passer de commande sur notre site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Le responsable du traitement est l’éditeur du site, dont l’identité et les coordonnées&nbsp;sont indiquées dans la rubrique «&nbsp;à propos&nbsp;».</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Les destinataires&nbsp;des données sont le responsable du traitement de données et ses prestataires qui interviennent dans l’exécution des commandes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Le responsable du traitement n’a pas l’intention d’effectuer un transfert de données à caractère personnel vers un pays tiers ou à une organisation internationale.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Les données seront conservées jusqu’à demande de suppression.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>La personne dont les données personnelles sont collectées a le&nbsp;droit :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>– de demander au responsable du traitement l’accès aux données à caractère personnel, la rectifi­cation ou l’effacement de celles-ci, ou une limitation du traitement relatif à la personne concernée,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>– de s’opposer au traitement,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>– à la portabilité de ses données,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>–&nbsp;d’introduire une réclamation auprès d’une autorité de contrôle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Aucun profilage ne sera réalisé et plus généralement aucune décision automatisée ne sera prise sur la base des données collectées.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'publish', 'closed', 'closed', '', 'vie-privee', '', '', '2024-06-07 14:13:56', '2024-06-07 14:13:56', '', 0, 'http://motaphotographie.local/?page_id=43', 0, 'page', '', 0),
(44, 1, '2024-05-21 13:52:44', '2024-05-21 13:52:44', '', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2024-05-21 13:52:44', '2024-05-21 13:52:44', '', 43, 'http://motaphotographie.local/?p=44', 0, 'revision', '', 0),
(45, 1, '2024-05-21 13:52:51', '2024-05-21 13:52:51', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://motaphotographie.local/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-05-21 13:52:51', '2024-05-21 13:52:51', '', 2, 'http://motaphotographie.local/?p=45', 0, 'revision', '', 0),
(46, 1, '2024-05-21 13:52:55', '2024-05-21 13:52:55', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://motaphotographie.local.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2024-05-21 13:52:55', '2024-05-21 13:52:55', '', 3, 'http://motaphotographie.local/?p=46', 0, 'revision', '', 0),
(47, 1, '2024-06-01 10:33:54', '2024-05-21 13:55:47', '', 'contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2024-06-01 10:33:54', '2024-06-01 10:33:54', '', 0, 'http://motaphotographie.local/?p=47', 3, 'nav_menu_item', '', 0),
(48, 1, '2024-06-01 10:33:54', '2024-05-21 13:55:47', ' ', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2024-06-01 10:33:54', '2024-06-01 10:33:54', '', 0, 'http://motaphotographie.local/?p=48', 2, 'nav_menu_item', '', 0),
(49, 1, '2024-06-01 10:33:54', '2024-05-21 13:55:47', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2024-06-01 10:33:54', '2024-06-01 10:33:54', '', 0, 'http://motaphotographie.local/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2024-05-21 13:59:25', '2024-05-21 13:59:25', '{"page_on_front":{"value":"37","type":"option","user_id":1,"date_modified_gmt":"2024-05-21 13:59:25"}}', '', '', 'trash', 'closed', 'closed', '', '9c6348fa-df1d-4d54-8f9f-e0dbbac1ed3d', '', '', '2024-05-21 13:59:25', '2024-05-21 13:59:25', '', 0, 'http://motaphotographie.local/9c6348fa-df1d-4d54-8f9f-e0dbbac1ed3d/', 0, 'customize_changeset', '', 0),
(53, 1, '2019-05-22 12:16:00', '2019-05-22 12:16:00', '<!-- wp:image {"id":17,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-3-683x1024.webp" alt="Tout est installé" class="wp-image-17"/></figure>\n<!-- /wp:image -->', 'Tout est installé', '', 'publish', 'closed', 'closed', '', 'tout-est-installe', '', '', '2024-05-23 10:52:59', '2024-05-23 10:52:59', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=53', 0, 'photographies', '', 0),
(54, 1, '2020-05-22 12:19:00', '2020-05-22 12:19:00', '<!-- wp:image {"id":18,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-4-683x1024.webp" alt="Vers l\'éternité " class="wp-image-18"/></figure>\n<!-- /wp:image -->', 'Vers l\'éternité', '', 'publish', 'closed', 'closed', '', 'vers-leternite', '', '', '2024-05-23 10:52:30', '2024-05-23 10:52:30', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=54', 0, 'photographies', '', 0),
(55, 1, '2021-05-22 12:22:00', '2021-05-22 12:22:00', '<!-- wp:image {"id":19,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-5-684x1024.webp" alt="Embrassez la mariée " class="wp-image-19"/></figure>\n<!-- /wp:image -->', 'Embrassez la mariée', '', 'publish', 'closed', 'closed', '', 'embrassez-la-mariee', '', '', '2024-05-23 10:51:52', '2024-05-23 10:51:52', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=55', 0, 'photographies', '', 0),
(56, 1, '2020-05-22 12:23:00', '2020-05-22 12:23:00', '<!-- wp:image {"id":20,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-6-1024x819.webp" alt="Dansons ensemble" class="wp-image-20"/></figure>\n<!-- /wp:image -->', 'Dansons ensemble', '', 'publish', 'closed', 'closed', '', '56', '', '', '2024-05-23 10:51:11', '2024-05-23 10:51:11', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=56', 0, 'photographies', '', 0),
(57, 1, '2019-05-22 12:35:00', '2019-05-22 12:35:00', '<!-- wp:image {"id":21,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-7-1024x683.webp" alt="Le menu" class="wp-image-21"/></figure>\n<!-- /wp:image -->', 'Le menu', '', 'publish', 'closed', 'closed', '', 'le-menu', '', '', '2024-05-23 10:50:28', '2024-05-23 10:50:28', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=57', 0, 'photographies', '', 0),
(58, 1, '2021-05-22 12:37:00', '2021-05-22 12:37:00', '<!-- wp:image {"id":22,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-8-684x1024.webp" alt="Au bal masqué " class="wp-image-22"/></figure>\n<!-- /wp:image -->', 'Au bal masqué', '', 'publish', 'closed', 'closed', '', 'au-bal-masque', '', '', '2024-05-23 10:49:34', '2024-05-23 10:49:34', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=58', 0, 'photographies', '', 0),
(59, 1, '2022-05-22 12:39:00', '2022-05-22 12:39:00', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":23,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-9-1024x683.webp" alt="Let\'s dance!" class="wp-image-23"/></figure>\n<!-- /wp:image -->', 'Let\'s dance!', '', 'publish', 'closed', 'closed', '', 'lets-dance', '', '', '2024-05-23 10:49:00', '2024-05-23 10:49:00', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=59', 0, 'photographies', '', 0),
(60, 1, '2022-05-22 12:40:00', '2022-05-22 12:40:00', '<!-- wp:image {"id":24,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-10-1024x768.webp" alt="Jour de match" class="wp-image-24"/></figure>\n<!-- /wp:image -->', 'Jour de match', '', 'publish', 'closed', 'closed', '', 'jour-de-match', '', '', '2024-05-23 10:48:04', '2024-05-23 10:48:04', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=60', 0, 'photographies', '', 0),
(61, 1, '2022-05-22 12:42:00', '2022-05-22 12:42:00', '<!-- wp:image {"id":25,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-11-1024x683.webp" alt="Préparation " class="wp-image-25"/></figure>\n<!-- /wp:image -->', 'Préparation', '', 'publish', 'closed', 'closed', '', 'preparation', '', '', '2024-05-23 10:47:32', '2024-05-23 10:47:32', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=61', 0, 'photographies', '', 0),
(62, 1, '2022-05-22 12:44:00', '2022-05-22 12:44:00', '<!-- wp:image {"id":26,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-12-1024x683.webp" alt="Bière ou eau plate ?" class="wp-image-26"/></figure>\n<!-- /wp:image -->', 'Bière ou eau plate ?', '', 'publish', 'closed', 'closed', '', 'biere-ou-eau-plate', '', '', '2024-05-23 10:47:07', '2024-05-23 10:47:07', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=62', 0, 'photographies', '', 0),
(63, 1, '2022-05-22 12:45:00', '2022-05-22 12:45:00', '<!-- wp:image {"id":27,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-13-683x1024.webp" alt="Bouquet final" class="wp-image-27"/></figure>\n<!-- /wp:image -->', 'Bouquet final', '', 'publish', 'closed', 'closed', '', 'bouquet-final', '', '', '2024-05-23 10:46:40', '2024-05-23 10:46:40', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=63', 0, 'photographies', '', 0),
(64, 1, '2022-05-22 12:47:00', '2022-05-22 12:47:00', '<!-- wp:image {"id":28,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-14-683x1024.webp" alt="Du soir au matin" class="wp-image-28"/></figure>\n<!-- /wp:image -->', 'Du soir au matin', '', 'publish', 'closed', 'closed', '', 'du-soir-au-matin', '', '', '2024-05-23 10:46:15', '2024-05-23 10:46:15', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=64', 0, 'photographies', '', 0),
(65, 1, '2022-05-22 12:48:00', '2022-05-22 12:48:00', '<!-- wp:image {"id":29,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="http://motaphotographie.local/wp-content/uploads/2024/05/nathalie-15.webp" alt="Team mariée" class="wp-image-29"/></figure>\n<!-- /wp:image -->', 'Team mariée', '', 'publish', 'closed', 'closed', '', 'team-mariee', '', '', '2024-05-28 16:53:37', '2024-05-28 16:53:37', '', 0, 'http://motaphotographie.local/?post_type=photographies&#038;p=65', 0, 'photographies', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(71, 1, '2024-05-22 15:46:41', '2024-05-22 15:46:41', 'a:29:{s:8:"taxonomy";s:16:"categorie_photos";s:11:"object_type";a:1:{i:0;s:13:"photographies";}s:22:"advanced_configuration";i:0;s:13:"import_source";s:0:"";s:11:"import_date";s:0:"";s:6:"labels";a:25:{s:4:"name";s:19:"Catégories_Photos ";s:13:"singular_name";s:16:"Catégorie_photo";s:9:"menu_name";s:19:"Catégories Photos ";s:9:"all_items";s:28:"Tout les Catégories Photos ";s:9:"edit_item";s:10:"Modifier C";s:9:"view_item";s:6:"Voir C";s:11:"update_item";s:16:"Mettre à jour C";s:12:"add_new_item";s:9:"Ajouter C";s:13:"new_item_name";s:16:"Nom du nouveau C";s:12:"search_items";s:30:"Rechercher Catégories Photos ";s:13:"popular_items";s:29:"Catégories Photos  populaire";s:26:"separate_items_with_commas";s:49:"Séparer les catégories photos  avec une virgule";s:19:"add_or_remove_items";s:38:"Ajouter ou retirer catégories photos ";s:21:"choose_from_most_used";s:56:"Choisir parmi les catégories photos  les plus utilisés";s:9:"most_used";s:0:"";s:9:"not_found";s:33:"Aucun catégories photos  trouvé";s:8:"no_terms";s:25:"Aucun catégories photos ";s:22:"name_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:22:"desc_field_description";s:0:"";s:21:"items_list_navigation";s:44:"Navigation dans la liste Catégories Photos ";s:10:"items_list";s:25:"Liste Catégories Photos ";s:13:"back_to_items";s:38:"← Aller à « catégories photos  »";s:9:"item_link";s:6:"Lien C";s:21:"item_link_description";s:17:"Un lien vers un c";}s:11:"description";s:0:"";s:12:"capabilities";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:6:"public";i:1;s:18:"publicly_queryable";i:1;s:12:"hierarchical";i:0;s:7:"show_ui";i:1;s:12:"show_in_menu";i:1;s:17:"show_in_nav_menus";i:1;s:12:"show_in_rest";i:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:5:"wp/v2";s:21:"rest_controller_class";s:24:"WP_REST_Terms_Controller";s:13:"show_tagcloud";i:1;s:18:"show_in_quick_edit";i:1;s:17:"show_admin_column";i:0;s:7:"rewrite";a:3:{s:17:"permalink_rewrite";s:12:"taxonomy_key";s:10:"with_front";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:12:"default_term";a:1:{s:20:"default_term_enabled";s:1:"0";}s:4:"sort";i:0;s:8:"meta_box";s:7:"default";s:11:"meta_box_cb";s:0:"";s:20:"meta_box_sanitize_cb";s:0:"";}', 'Catégories_Photos', 'categories_photos', 'trash', 'closed', 'closed', '', 'taxonomy_664e12676aa72__trashed', '', '', '2024-05-22 16:00:45', '2024-05-22 16:00:45', '', 0, 'http://motaphotographie.local/?post_type=acf-taxonomy&#038;p=71', 0, 'acf-taxonomy', '', 0),
(72, 1, '2024-05-22 16:06:07', '2024-05-22 16:06:07', 'a:29:{s:8:"taxonomy";s:16:"categorie_photos";s:11:"object_type";a:1:{i:0;s:13:"photographies";}s:22:"advanced_configuration";b:1;s:13:"import_source";s:5:"cptui";s:11:"import_date";i:1716393967;s:6:"labels";a:29:{s:13:"singular_name";s:16:"catégorie_photo";s:4:"name";s:19:"catégories_photos ";s:9:"menu_name";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:9:"all_items";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:22:"name_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:24:"parent_field_description";s:0:"";s:22:"desc_field_description";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:14:"filter_by_item";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:9:"most_used";s:0:"";s:13:"back_to_items";s:0:"";s:9:"item_link";s:0:"";s:21:"item_link_description";s:0:"";}s:11:"description";s:49:"Type d&#39;évènement a l&#39;origine du cliché";s:12:"capabilities";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:6:"public";b:1;s:18:"publicly_queryable";b:1;s:12:"hierarchical";b:0;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"show_in_nav_menus";b:1;s:12:"show_in_rest";b:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:0:"";s:21:"rest_controller_class";s:0:"";s:13:"show_tagcloud";b:0;s:18:"show_in_quick_edit";s:0:"";s:17:"show_admin_column";b:0;s:7:"rewrite";a:4:{s:17:"permalink_rewrite";s:12:"taxonomy_key";s:4:"slug";s:0:"";s:10:"with_front";b:1;s:20:"rewrite_hierarchical";b:0;}s:9:"query_var";s:12:"taxonomy_key";s:14:"query_var_name";s:0:"";s:12:"default_term";a:4:{s:20:"default_term_enabled";b:0;s:17:"default_term_name";s:0:"";s:17:"default_term_slug";s:0:"";s:24:"default_term_description";s:0:"";}s:4:"sort";b:0;s:8:"meta_box";s:7:"default";s:11:"meta_box_cb";s:0:"";s:20:"meta_box_sanitize_cb";s:0:"";}', 'catégories_photos', 'categories_photos', 'publish', 'closed', 'closed', '', 'taxonomy_664e17efd18e4', '', '', '2024-05-22 16:06:07', '2024-05-22 16:06:07', '', 0, 'http://motaphotographie.local/?post_type=acf-taxonomy&p=72', 0, 'acf-taxonomy', '', 0),
(73, 1, '2024-05-23 12:37:56', '2024-05-23 12:37:56', '{"show_on_front":{"value":"posts","type":"option","user_id":1,"date_modified_gmt":"2024-05-23 12:37:56"}}', '', '', 'trash', 'closed', 'closed', '', '3dfb0ade-20e3-4f1b-98bb-9fec14e9dc71', '', '', '2024-05-23 12:37:56', '2024-05-23 12:37:56', '', 0, 'http://motaphotographie.local/3dfb0ade-20e3-4f1b-98bb-9fec14e9dc71/', 0, 'customize_changeset', '', 0),
(74, 1, '2024-05-23 16:47:50', '2024-05-23 16:47:50', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2024-05-23 16:47:50', '2024-05-23 16:47:50', '', 0, 'http://motaphotographie.local/?p=74', 1, 'nav_menu_item', '', 0),
(75, 1, '2024-05-23 16:47:50', '2024-05-23 16:47:50', ' ', '', '', 'publish', 'closed', 'closed', '', '75', '', '', '2024-05-23 16:47:50', '2024-05-23 16:47:50', '', 0, 'http://motaphotographie.local/?p=75', 2, 'nav_menu_item', '', 0),
(76, 1, '2024-05-23 16:47:50', '2024-05-23 16:47:50', ' ', '', '', 'publish', 'closed', 'closed', '', '76', '', '', '2024-05-23 16:47:50', '2024-05-23 16:47:50', '', 0, 'http://motaphotographie.local/?p=76', 3, 'nav_menu_item', '', 0),
(80, 1, '2024-06-01 09:43:04', '2024-06-01 09:43:04', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-06-01 09:43:04', '2024-06-01 09:43:04', '', 1, 'http://motaphotographie.local/?p=80', 0, 'revision', '', 0),
(81, 1, '2024-06-01 10:10:53', '2024-06-01 10:10:53', '{"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2024-06-01 10:09:35"},"page_for_posts":{"value":"37","type":"option","user_id":1,"date_modified_gmt":"2024-06-01 10:10:53"},"page_on_front":{"value":"0","type":"option","user_id":1,"date_modified_gmt":"2024-06-01 10:10:53"}}', '', '', 'trash', 'closed', 'closed', '', 'b2bee377-f959-4e43-b9ec-830ab11b983c', '', '', '2024-06-01 10:10:53', '2024-06-01 10:10:53', '', 0, 'http://motaphotographie.local/?p=81', 0, 'customize_changeset', '', 0),
(82, 1, '2024-06-05 11:28:08', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-06-05 11:28:08', '0000-00-00 00:00:00', '', 0, 'http://motaphotographie.local/?p=82', 0, 'post', '', 0),
(84, 1, '2024-06-07 14:13:56', '2024-06-07 14:13:56', '<!-- wp:heading -->\n<h2 class="wp-block-heading"><strong>Données personnelles</strong></h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous effectuons un traitement de données personnelles destiné à l’exécution des commandes passées sur notre site Internet et à la gestion de la relation avec nos clients. Ce traitement est&nbsp;nécessaire à l’exécution de mesures précontractuelles prises à votre demande et à l’exécution du contrat conclu entre nous. Il est fondé sur l’article 6, paragraphe 1, point b), du règlement général sur la protection des données (règlement UE 2016/679 du Parlement européen et du Conseil du 27 avril 2016 – RGPD).&nbsp;La demande de données conditionne la conclusion du contrat. Elle&nbsp;a un caractère contractuel. La personne concernée est&nbsp;tenue de fournir les données. À défaut, elle ne pourra pas passer de commande sur notre site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Le responsable du traitement est l’éditeur du site, dont l’identité et les coordonnées&nbsp;sont indiquées dans la rubrique «&nbsp;à propos&nbsp;».</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Les destinataires&nbsp;des données sont le responsable du traitement de données et ses prestataires qui interviennent dans l’exécution des commandes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Le responsable du traitement n’a pas l’intention d’effectuer un transfert de données à caractère personnel vers un pays tiers ou à une organisation internationale.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Les données seront conservées jusqu’à demande de suppression.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>La personne dont les données personnelles sont collectées a le&nbsp;droit :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>– de demander au responsable du traitement l’accès aux données à caractère personnel, la rectifi­cation ou l’effacement de celles-ci, ou une limitation du traitement relatif à la personne concernée,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>– de s’opposer au traitement,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>– à la portabilité de ses données,</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>–&nbsp;d’introduire une réclamation auprès d’une autorité de contrôle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Aucun profilage ne sera réalisé et plus généralement aucune décision automatisée ne sera prise sur la base des données collectées.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2024-06-07 14:13:56', '2024-06-07 14:13:56', '', 43, 'http://motaphotographie.local/?p=84', 0, 'revision', '', 0) ;

#
# Fin du contenu des données de la table `wp_posts`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Structure de la table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(30, 6, 0),
(30, 19, 0),
(31, 6, 0),
(31, 19, 0),
(32, 6, 0),
(32, 18, 0),
(47, 10, 0),
(48, 10, 0),
(49, 10, 0),
(53, 7, 0),
(53, 21, 0),
(54, 7, 0),
(54, 21, 0),
(55, 7, 0),
(55, 21, 0),
(56, 6, 0),
(56, 21, 0),
(57, 6, 0),
(57, 21, 0),
(58, 7, 0),
(58, 18, 0),
(59, 6, 0),
(59, 21, 0),
(60, 6, 0),
(60, 20, 0),
(61, 6, 0),
(61, 18, 0),
(62, 6, 0),
(62, 18, 0),
(63, 7, 0),
(63, 21, 0),
(64, 7, 0),
(64, 21, 0),
(65, 7, 0),
(65, 21, 0),
(74, 11, 0),
(75, 11, 0),
(76, 11, 0) ;

#
# Fin du contenu des données de la table `wp_term_relationships`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Structure de la table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'categories', 'photographie réalisée lors de réception ', 0, 0),
(3, 3, 'categories', 'photographie réalisée lors de concert.', 0, 0),
(4, 4, 'categories', 'Photographie autour du mariage.', 0, 0),
(5, 5, 'categories', 'photographie réalisée lors d\'émission télévisé ', 0, 0),
(6, 6, 'formats', 'Orientation de l\'image (horizontale)', 0, 9),
(7, 7, 'formats', 'Orientation de l\'image (verticale)', 0, 7),
(8, 8, 'category', '', 0, 0),
(9, 9, 'category', '', 0, 0),
(10, 10, 'nav_menu', '', 0, 3),
(11, 11, 'nav_menu', '', 0, 3),
(12, 12, 'category', '', 0, 0),
(13, 13, 'category', '', 0, 0),
(14, 14, 'categorie_photo', 'catégorie d\'événement a l\'origine du cliché.', 0, 0),
(15, 15, 'categorie_photo', 'catégorie d’événement a l’origine du cliché.', 0, 0),
(16, 16, 'categorie_photo', 'catégorie d’événement a l’origine du cliché.', 0, 0),
(17, 17, 'categorie_photo', 'catégorie d’événement a l’origine du cliché.', 0, 0),
(18, 18, 'categorie_photos', '', 0, 4),
(19, 19, 'categorie_photos', '', 0, 2),
(20, 20, 'categorie_photos', '', 0, 1),
(21, 21, 'categorie_photos', '', 0, 9) ;

#
# Fin du contenu des données de la table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Structure de la table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_termmeta`
#

#
# Fin du contenu des données de la table `wp_termmeta`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Structure de la table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Réception', 'reception', 0),
(3, 'Concert', 'concert', 0),
(4, 'Mariage', 'mariage', 0),
(5, 'télévision', 'television', 0),
(6, 'paysage', 'paysage', 0),
(7, 'portrait', 'portrait', 0),
(8, 'Réception', 'reception', 0),
(9, 'Concert', 'concert', 0),
(10, 'principal', 'principal', 0),
(11, 'footer', 'footer', 0),
(12, 'Mariage', 'mariage', 0),
(13, 'Télévision', 'television', 0),
(14, 'Réception', 'reception', 0),
(15, 'Concert', 'concert', 0),
(16, 'Mariage', 'mariage', 0),
(17, 'Télévision', 'television', 0),
(18, 'Concert', 'concert', 0),
(19, 'Réception', 'reception', 0),
(20, 'Télévision', 'television', 0),
(21, 'Mariage', 'mariage', 0) ;

#
# Fin du contenu des données de la table `wp_terms`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Structure de la table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'devlopr'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"a55b66444ead78e90ea614f9fe0337d929b12e83330f4f02ce51472c37913f21";a:4:{s:10:"expiration";i:1718451755;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";s:5:"login";i:1717242155;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '82'),
(18, 1, 'wp_persisted_preferences', 'a:3:{s:14:"core/edit-post";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;}s:4:"core";a:1:{s:10:"openPanels";a:8:{i:0;s:11:"post-status";i:1;s:25:"taxonomy-panel-categories";i:2;s:14:"featured-image";i:3;s:30:"taxonomy-panel-categorie_photo";i:4;s:31:"taxonomy-panel-categorie_photos";i:5;s:22:"taxonomy-panel-formats";i:6;s:15:"page-attributes";i:7;s:16:"discussion-panel";}}s:9:"_modified";s:24:"2024-06-01T09:08:19.213Z";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1716296258'),
(21, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(22, 1, 'metaboxhidden_dashboard', 'a:1:{i:0;s:17:"dashboard_primary";}'),
(23, 1, 'manageedit-acf-taxonomycolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(24, 1, 'acf_user_settings', 'a:2:{s:20:"taxonomies-first-run";b:1;s:19:"post-type-first-run";b:1;}'),
(25, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(26, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(27, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:27:"add-post-type-photographies";i:1;s:12:"add-post_tag";i:2;s:14:"add-categories";i:3;s:11:"add-formats";}'),
(28, 1, 'nav_menu_recently_edited', '10'),
(29, 1, 'closedpostboxes_acf-taxonomy', 'a:0:{}'),
(30, 1, 'metaboxhidden_acf-taxonomy', 'a:1:{i:0;s:7:"slugdiv";}') ;

#
# Fin du contenu des données de la table `wp_usermeta`
# --------------------------------------------------------



#
# Supprimer toute table existante `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Structure de la table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Données de la table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'devlopr', '$P$BAI.1EkWjVjDqvPEfUz3K7deZe/bQE1', 'devlopr', 'dev-email@wpengine.local', 'http://motaphotographie.local', '2024-05-21 10:20:22', '', 0, 'devlopr') ;

#
# Fin du contenu des données de la table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

